/* Data: subjects and their coefficients and rules */
const subjects = [
  {key:'Embryologie', coef:1, type:'embryo', td:true, semestral:false},
  {key:'SSH', coef:1, type:'single', td:false, semestral:true},
  {key:'Histologie', coef:1, type:'single', td:false, semestral:true},
  {key:'Physiologie', coef:1, type:'single', td:false, semestral:true},
  {key:'Biochimie', coef:2, type:'noTD', td:false, semestral:false},
  {key:'Anatomie', coef:4, type:'td', td:true, semestral:false},
  {key:'Biophysique', coef:2, type:'td', td:true, semestral:false},
  {key:'Biostatistiques', coef:2, type:'td', td:true, semestral:false}
];

// Splash screen & init
window.addEventListener('load', ()=>{
  setTimeout(()=>{
    document.getElementById('splash').style.display='none';
    document.getElementById('app').classList.remove('hidden');
  },900);
  buildTable();
  renderCourses();
  loadUploadedFiles();
});

function buildTable(){
  const tbody = document.querySelector('#subjectsTable tbody');
  tbody.innerHTML='';
  subjects.forEach(s=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${s.key}</td>
      <td>${s.type==='single' ? '-' : '<input type="number" min="0" max="20" step="0.01" class="s1">'} </td>
      <td>${s.type==='single' ? '<input type="number" min="0" max="20" step="0.01" class="s2">' : (s.type==='embryo'?'-':'<input type="number" min="0" max="20" step="0.01" class="s2">')}</td>
      <td>${s.td?'<input type="number" min="0" max="20" step="0.01" class="td">':'-'}</td>
      <td>${s.coef}</td>
      <td class="res"></td>
    `;
    tbody.appendChild(tr);
  });
}

// Calculation rules per your app spec
document.getElementById('calcBtn').addEventListener('click', ()=>{
  const rows = document.querySelectorAll('#subjectsTable tbody tr');
  let total = 0;
  // coefficients sum not used in denominator (we divide by 16 at end)
  rows.forEach((row,i)=>{
    const name = subjects[i].key;
    const coef = subjects[i].coef;
    const s1 = row.querySelector('.s1') ? parseFloat(row.querySelector('.s1').value) : null;
    const s2 = row.querySelector('.s2') ? parseFloat(row.querySelector('.s2').value) : null;
    const td = row.querySelector('.td') ? parseFloat(row.querySelector('.td').value) : null;

    let moyenne = null;
    if (subjects[i].type === 'embryo') {
      // Embryologie: (S1*2 + TD)/3  OR if only S1 present use S1
      if (!isNaN(s1) && !isNaN(td)) moyenne = (s1*2 + td)/3;
      else if (!isNaN(s1)) moyenne = s1;
      else if (!isNaN(td)) moyenne = td;
    } else if (subjects[i].type === 'noTD') {
      // Biochimie: average of S1 & S2 or single value
      if (!isNaN(s1) && !isNaN(s2)) moyenne = (s1 + s2)/2;
      else if (!isNaN(s1)) moyenne = s1;
      else if (!isNaN(s2)) moyenne = s2;
    } else if (subjects[i].td) {
      // subjects with TD/TP: ((S1 + S2)*2 + TD)/5 if all present
      if (!isNaN(s1) && !isNaN(s2) && !isNaN(td)) moyenne = ((s1 + s2)*2 + td)/5;
      else if (!isNaN(s1) && !isNaN(s2)) moyenne = (s1 + s2)/2;
      else if (!isNaN(s1)) moyenne = s1;
      else if (!isNaN(s2)) moyenne = s2;
      else if (!isNaN(td)) moyenne = td;
    } else if (subjects[i].type === 'single') {
      // semestrial single note (SSH, Histo, Physio) only one input (we placed in S1 or S2)
      if (!isNaN(s1)) moyenne = s1;
      else if (!isNaN(s2)) moyenne = s2;
    }

    const resCell = row.querySelector('.res');
    if (moyenne !== null && !isNaN(moyenne)) {
      resCell.innerText = moyenne.toFixed(2);
      total += moyenne * coef;
    } else {
      resCell.innerText = '';
    }
  });

  const final = (total / 16);
  const finalStr = isNaN(final) ? '0.00' : final.toFixed(2);
  document.getElementById('resultText').innerText = "Votre moyenne finale est : " + finalStr + " / 20";
  document.getElementById('popup').classList.remove('hidden');
});

document.getElementById('closePopup').addEventListener('click', ()=>{
  document.getElementById('popup').classList.add('hidden');
});

// Dark mode & language (simple toggle)
document.getElementById('modeToggle').addEventListener('click', ()=>{
  document.body.classList.toggle('dark');
});
document.getElementById('langToggle').addEventListener('click', ()=>{
  alert('التبديل إلى العربية سيُطبّق في النسخ القادمة. (نسخة فرنسية حالياً)');
});

// Admin login (code aziz1968) and local uploads
document.getElementById('adminBtn').addEventListener('click', ()=>{
  const code = prompt('Entrez le code secret:');
  if (code === 'aziz1968') {
    document.getElementById('adminArea').classList.remove('hidden');
    document.getElementById('app').classList.add('hidden');
    loadUploadedFiles();
  } else {
    alert('Code incorrect');
  }
});
document.getElementById('closeAdmin').addEventListener('click', ()=>{
  document.getElementById('adminArea').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
});

// Upload: store file metadata and object URL in localStorage for session persistence
document.getElementById('uploadBtn').addEventListener('click', ()=>{
  const input = document.getElementById('fileInput');
  const files = input.files;
  if (!files.length) return alert('Sélectionnez des fichiers');
  const stored = JSON.parse(localStorage.getItem('minou_files')||'[]');
  Array.from(files).forEach(f=>{
    const url = URL.createObjectURL(f);
    stored.push({name:f.name, size:f.size, url:url, ts:Date.now()});
  });
  localStorage.setItem('minou_files', JSON.stringify(stored));
  loadUploadedFiles();
  alert('Fichiers ajoutés (stockés localement dans votre navigateur)');
});

function loadUploadedFiles(){
  const list = document.getElementById('uploadedFiles');
  list.innerHTML='';
  const stored = JSON.parse(localStorage.getItem('minou_files')||'[]');
  if (!stored.length) { list.innerHTML='<p>Aucun fichier uploadé.</p>'; return; }
  stored.forEach((f,i)=>{
    const div = document.createElement('div');
    div.innerHTML = `<a href="${f.url}" download="${f.name}">${f.name}</a> — ${Math.round(f.size/1024)} KB <button data-i="${i}" class="delBtn">Supprimer</button>`;
    list.appendChild(div);
  });
  document.querySelectorAll('.delBtn').forEach(b=>b.addEventListener('click',(e)=>{
    const i = parseInt(e.target.dataset.i);
    const stored = JSON.parse(localStorage.getItem('minou_files')||'[]');
    stored.splice(i,1);
    localStorage.setItem('minou_files', JSON.stringify(stored));
    loadUploadedFiles();
  }));
}

// Render courses list (click to show options)
function renderCourses(){
  const wrap = document.getElementById('coursesList');
  wrap.innerHTML='';
  subjects.forEach(s=>{
    const div = document.createElement('div');
    div.className='courseItem';
    div.innerHTML = `<strong>${s.key}</strong> — <button class="btnCours">Cours</button> <button class="btnCours">Examens</button> <button class="btnCours">TD/TP</button>`;
    wrap.appendChild(div);
  });
}

// "Download PDF" opens a printable page (user can Save as PDF)
document.getElementById('downloadPdf').addEventListener('click', ()=>{
  const rows = document.querySelectorAll('#subjectsTable tbody tr');
  let html = `<html><head><title>Minou Med - Résultat</title><style>body{font-family: Arial; padding:20px} table{width:100%;border-collapse:collapse} th,td{border:1px solid #ddd;padding:6px;text-align:center}</style></head><body>`;
  html += `<h2>Minou Med — Résultat</h2>`;
  html += `<table><tr><th>Matière</th><th>Résultat</th><th>Coef</th></tr>`;
  rows.forEach((row,i)=>{
    const name = subjects[i].key;
    const res = row.querySelector('.res').innerText || '-';
    const coef = subjects[i].coef;
    html += `<tr><td>${name}</td><td>${res}</td><td>${coef}</td></tr>`;
  });
  html += `</table><p>Généré le: ${new Date().toLocaleString()}</p>`;
  html += `</body></html>`;
  const w = window.open('','_blank');
  w.document.write(html);
  w.document.close();
  w.print();
});
